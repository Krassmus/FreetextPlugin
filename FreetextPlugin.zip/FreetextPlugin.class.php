<?php

require_once __DIR__."/lib/Freetext.php";

class FreetextPlugin extends StudIPPlugin implements SystemPlugin
{
}